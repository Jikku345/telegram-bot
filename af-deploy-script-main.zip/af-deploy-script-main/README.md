# af-deploy-script

<!-- ## Railway

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=)
<br> -->

## Heroku

Deploy to heroku.
<p align="center">
<a href="https://heroku.com/deploy?template=https://github.com/AlbertEinsteinTG/af-deploy-script">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>

