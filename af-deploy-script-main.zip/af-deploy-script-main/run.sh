export TERM=xterm;

git clone "${REPO_URL:-https://github.com/CrazyBotsz/Adv-Auto-Filter-Bot-V2}" Auto_Filter
cd Auto_Filter
echo "Starting...!";
python3 -m bot

